package enums;

/**
 * @author tisaac
 */
public enum StepType {
    REQUESTOR,
    APPROVER
}
