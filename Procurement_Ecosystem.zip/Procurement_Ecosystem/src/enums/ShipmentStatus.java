package enums;

/**
 * @author tisaac
 */
public enum ShipmentStatus {
    PLACED, IN_TRANSIT, DELIVERED
}
