package enums;

/**
 * @author tisaac
 */
public enum OrganizationType {
    IT,
    FINANCE,
    PROCUREMENT,
    LEGAL,
    HR,
    WAREHOUSE,
    CUSTOMER_SERVICE,
    SALES,
    LOGISTICS
}
