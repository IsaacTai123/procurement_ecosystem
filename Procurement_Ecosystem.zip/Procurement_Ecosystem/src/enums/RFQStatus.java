package enums;

/**
 * @author tisaac
 */
public enum RFQStatus {
    DRAFT,
    SENT,
    RECEIVED,
    EXPIRED,
    CLOSED,
}
