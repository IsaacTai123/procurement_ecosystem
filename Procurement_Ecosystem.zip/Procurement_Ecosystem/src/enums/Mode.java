package enums;

/**
 * @author tisaac
 */
public enum Mode {
    ADD, UPDATE
}
