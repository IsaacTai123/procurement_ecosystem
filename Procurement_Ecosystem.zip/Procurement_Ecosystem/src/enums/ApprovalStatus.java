package enums;

/**
 * @author tisaac
 */
public enum ApprovalStatus {
    PENDING,
    SUBMITTED,
    APPROVED,
    REJECTED,
    SKIPPED
}
