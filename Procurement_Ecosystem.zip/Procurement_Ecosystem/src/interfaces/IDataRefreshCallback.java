package interfaces;

/**
 * @author tisaac
 */
public interface IDataRefreshCallback {
    void refreshData();
}
