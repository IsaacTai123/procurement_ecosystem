package interfaces;

/**
 * @author tisaac
 */
public interface IDataRefreshCallbackAware {
    void setCallback(IDataRefreshCallback callback);
}
