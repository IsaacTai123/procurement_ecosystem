/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.ecosystem.Enterprise;
import model.quotation.RFQ;

/**
 *
 * @author linweihong
 */
public class VendorController {
    public void submitQuotation(RFQ rfq, Enterprise vendor, double price, String spec) {
        // logic to submit quotation
    }
}
