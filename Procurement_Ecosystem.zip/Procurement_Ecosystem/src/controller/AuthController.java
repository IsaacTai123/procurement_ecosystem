/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.ecosystem.Network;
import model.user.UserAccount;

/**
 *
 * @author linweihong
 */
public class AuthController {
    public UserAccount login(String username, String password, Network network) {
        // logic for login across all organizations in the network
        return null;
    }
}
